var rgbled = require("rgbled");
rgbled.set(255, 255, 0); // 红色+绿色=黄色