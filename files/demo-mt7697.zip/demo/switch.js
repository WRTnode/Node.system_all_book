var pinmux = require("pinmux");
var extint = require("extint");
var pinno = 37;
pinmux.set(pinno, 3); // 模式3为中断输入模式
var eno = extint.pin2eint(pinno);   // 通过引脚号查询对应的外部中断号
extint.init(eno, "rise_edge", 10);  // 上升沿触发，消抖时间为10毫秒
var handler = extint.register(eno, function(){
    print("KEY1 DOWN");
});                                 // 注册中断响应函数，但按钮按下时，打印 "KEY1 DOWN"
                                    // handler为该事件的控制器