var pinmux = require("pinmux");
var gpio = require("gpio");
pinmux.set(29, 8);      // 将GPIO29引脚配置为普通IO口模式
pinmux.set(30, 8);      // 将GPIO30引脚配置为普通IO口模式
var m1 = gpio.open(29); // 打开GPIO29引脚，获得引脚对象
var m2 = gpio.open(30); // 打开GPIO30引脚，获得引脚对象
m1.direction("out");    // 配置为输出
m2.direction("out");    // 配置为输出
m1.pull("down");        // 配置为下拉
m2.pull("down");        // 配置为下拉
m1.write(true);         // GPIO29拉高
m2.write(false);        // GPIO30拉低